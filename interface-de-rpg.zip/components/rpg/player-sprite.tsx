"use client"

import Image from "next/image"
import type { PlayerState } from "@/hooks/use-player-controls"

export interface PlayerSpriteProps {
  src: string
  name?: string
  state: PlayerState
  /**
   * Enquadramento da pose "hero" dentro da folha de sprites enviada.
   * Como as imagens são model sheets, ampliamos e deslocamos para focar
   * apenas o personagem grande (pose central). Ajuste conforme a sua arte.
   */
  frame?: {
    /** Zoom aplicado à imagem (ex.: 2.6 = 260%). */
    scale?: number
    /** object-position CSS, ex.: "52% 62%". */
    position?: string
  }
}

/**
 * Renderiza o herói no cenário reagindo ao estado de controle.
 * Usa uma única imagem de sprite e simula os quadros de animação via
 * CSS (balanço ao andar, offset ao pular, giro/brilho ao atacar). Para usar
 * um spritesheet real, troque a <Image> por um recorte com background-position.
 */
export function PlayerSprite({
  src,
  name = "Herói",
  state,
  frame = { scale: 2.6, position: "52% 60%" },
}: PlayerSpriteProps) {
  const { x, y, facing, action, jumping, attacking } = state

  // Direção: espelha horizontalmente quando virado para a esquerda.
  const flip = facing === "left" ? -1 : 1

  // Offset vertical do pulo (arco simples).
  const jumpOffset = jumping ? -46 : 0

  const bodyAnim = action === "walk" ? "anim-walk" : action === "idle" ? "anim-idle" : ""

  return (
    <div
      className="pointer-events-none absolute left-1/2 top-1/2 z-[5]"
      style={{
        transform: `translate(-50%, -50%) translate(${x}px, ${y}px)`,
        transition: "transform 60ms linear",
      }}
      aria-label={`${name} (${action})`}
      role="img"
    >
      {/* Sombra */}
      <div
        className="absolute left-1/2 top-full h-3 w-16 -translate-x-1/2 rounded-[50%] bg-black/45 blur-[1px]"
        style={{ transform: `translateX(-50%) scaleX(${jumping ? 0.7 : 1})` }}
        aria-hidden="true"
      />

      {/* Corpo do jogador */}
      <div
        className={bodyAnim}
        style={{
          transform: `translateY(${jumpOffset}px)`,
          transition: "transform 200ms cubic-bezier(0.3, -0.4, 0.4, 1.4)",
        }}
      >
        <div
          className="relative h-28 w-24 overflow-hidden"
          style={{ transform: `scaleX(${flip})` }}
        >
          {/* Brilho/impacto do ataque */}
          {attacking && (
            <span
              className="absolute -right-3 top-1/2 z-10 h-16 w-16 -translate-y-1/2 rounded-full bg-amber-300/70 blur-md"
              aria-hidden="true"
            />
          )}
          <Image
            src={src || "/placeholder.svg"}
            alt=""
            fill
            sizes="112px"
            className="pixelated object-cover drop-shadow-[3px_4px_0_rgba(0,0,0,0.5)]"
            style={{
              objectPosition: frame.position,
              scale: String(frame.scale),
              transform: attacking ? "rotate(-8deg) translateX(6px)" : "none",
              transition: "transform 120ms ease-out",
            }}
            priority
          />
        </div>
      </div>

      {/* Etiqueta da ação (feedback visual) */}
      {(attacking || jumping) && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 whitespace-nowrap">
          <span
            className="font-pixel text-[8px] text-amber-200"
            style={{ textShadow: "1px 1px 0 #000", transform: `scaleX(${flip})` }}
          >
            {attacking ? "ATAQUE!" : "PULO!"}
          </span>
        </div>
      )}
    </div>
  )
}
