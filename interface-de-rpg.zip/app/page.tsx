"use client"

import { useCallback, useEffect, useState } from "react"
import { GameHud } from "@/components/rpg/game-hud"
import { IntroCutscene } from "@/components/rpg/intro-cutscene"
import { PlayerSprite } from "@/components/rpg/player-sprite"
import { usePlayerControls } from "@/hooks/use-player-controls"
import { INTRO_NPC, MAIN_OBJECTIVE, PARTY } from "@/lib/characters"

type Phase = "intro" | "dialogue" | "playing"

const DIALOGUE_LINES = [
  "Vocês não são daqui, forasteiros... o Tabuleiro os trouxe através do véu do tempo.",
  "Um feiticeiro sombrio raptou a Princesa Elara e a aprisionou na Torre Carmesim.",
  "Libertem a princesa e o portal de volta ao seu mundo se abrirá. O destino de dois mundos está em suas mãos.",
]

export default function Page() {
  const [phase, setPhase] = useState<Phase>("intro")
  const [line, setLine] = useState(0)

  // Personagem principal = primeiro do elenco (Murilo, o Paladino).
  const hero = PARTY[0]

  // Controles ativos apenas na fase de jogo.
  const player = usePlayerControls(phase === "playing")

  // Avança o diálogo; na última fala, fecha a caixa e entra no gameplay.
  const advanceDialogue = useCallback(() => {
    setLine((prev) => {
      if (prev >= DIALOGUE_LINES.length - 1) {
        setPhase("playing")
        return prev
      }
      return prev + 1
    })
  }, [])

  // Teclas para avançar o diálogo: Espaço ou E.
  useEffect(() => {
    if (phase !== "dialogue") return
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.code === "KeyE") {
        e.preventDefault()
        advanceDialogue()
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [phase, advanceDialogue])

  if (phase === "intro") {
    return (
      <IntroCutscene
        onEnter={() => {
          setLine(0)
          setPhase("dialogue")
        }}
      />
    )
  }

  const inDialogue = phase === "dialogue"

  return (
    <main className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-stone-950">
      {/* Cenário do jogo */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('/sprites/village-bg.png')",
          imageRendering: "pixelated",
        }}
        aria-hidden="true"
      />
      <div className="absolute inset-0 bg-black/25" aria-hidden="true" />

      {/* Herói controlável (aparece já no gameplay) */}
      {phase === "playing" && (
        <PlayerSprite src={hero.image} name={hero.realName} state={player} />
      )}

      {/* HUD do jogo */}
      <div
        className={inDialogue ? "absolute inset-0 cursor-pointer" : "absolute inset-0"}
        onClick={inDialogue ? advanceDialogue : undefined}
      >
        <GameHud
          showDialogue={inDialogue}
          player={{
            name: hero.realName,
            avatarSrc: hero.image,
            level: 1,
            hp: { current: hero.hp, max: hero.hp },
            mp: { current: hero.mp, max: hero.mp },
            objective: MAIN_OBJECTIVE,
          }}
          quest={{
            title: "Missão Principal",
            objectives: [{ label: "Salvar a Princesa Elara", current: 0, total: 1 }],
          }}
          dialogue={{
            npcName: INTRO_NPC.name,
            npcSpriteSrc: INTRO_NPC.image,
            text: DIALOGUE_LINES[line],
            continueHint:
              line >= DIALOGUE_LINES.length - 1
                ? "Pressione ESPAÇO para começar..."
                : "Pressione ESPAÇO para continuar...",
          }}
        />
      </div>

      {/* Dica de controles durante o gameplay */}
      {phase === "playing" && (
        <div className="pointer-events-none absolute bottom-4 left-1/2 z-20 -translate-x-1/2">
          <div className="border-2 border-amber-600/70 bg-black/70 px-3 py-2">
            <p className="font-pixel-body text-center text-[15px] leading-tight text-amber-100">
              <span className="text-amber-400">WASD</span> mover {" · "}
              <span className="text-amber-400">J / Espaço</span> atacar {" · "}
              <span className="text-amber-400">K / Shift / ↑</span> pular
            </p>
          </div>
        </div>
      )}
    </main>
  )
}
